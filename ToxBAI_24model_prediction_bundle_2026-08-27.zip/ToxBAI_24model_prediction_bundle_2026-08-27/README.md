# ToxBAI 24-model prediction bundle

이 ZIP 하나에는 24개 endpoint 모델, 모델별 feature 생성법, 통일된 applicability domain(AD) 참조구조와 임계값, 실행 스크립트가 포함되어 있습니다.

## 가장 간단한 사용법

1. ZIP을 풉니다.
2. `input_template.csv` 형식으로 `ID`와 `SMILES` 열을 준비합니다.
3. 다음 명령을 실행합니다.

```bash
python predict_24.py input_template.csv -o predictions.xlsx
```

SMILES 하나만 바로 분석할 수도 있습니다.

```bash
python predict_24.py --smiles "CCO" -o ethanol_predictions.xlsx
```

macOS에서는 `run_prediction.command`에 입력 CSV/XLSX를 끌어다 놓아 실행할 수도 있습니다.

## 환경 설치

Conda 사용을 권장합니다.

```bash
conda env create -f environment.yml
conda activate tox-bai-24
python predict_24.py input_template.csv -o predictions.xlsx
```

또는 현재 Python 환경에 설치합니다.

```bash
python -m pip install -r requirements.txt
```

## 입력 형식

- CSV, XLSX, XLS 또는 JSON
- 기본 SMILES 열 이름: `SMILES`
- 기본 ID 열 이름: `ID`
- 열 이름이 다르면 `--smiles-column` 및 `--id-column`을 사용합니다.
- 염·혼합물은 RDKit Cleanup → FragmentParent → Uncharger 순서로 표준화합니다.

## 출력

기본 XLSX 출력에는 다음 시트가 생성됩니다.

- `Summary`: endpoint별 예측 및 AD 요약
- `Prediction`: PRED-0/PRED-1 행렬
- `Probability`: 양성 확률
- `AD Tmax`: endpoint 학습참조와의 최대 Tanimoto similarity
- `AD Flag`: In domain/Out of domain
- `Detail`: 물질 × endpoint 상세 결과
- `Model manifest`: 24개 모델의 알고리즘, cutoff, AD threshold 및 checksum

출력 파일 확장자를 `.csv` 또는 `.json`으로 지정하면 long-format 상세 결과로 저장합니다.

## AD 방법

- 구조: RDKit Cleanup → FragmentParent → Uncharger → canonical isomeric SMILES
- fingerprint: Morgan radius 2, 2,048 bits
- 학습물질 density: 자기 자신을 제외한 최근접 top-5 Tanimoto 평균
- 모델별 AD threshold: 학습 density 분포의 5th percentile
- Query score: 해당 endpoint 학습 참조구조에 대한 최대 Tanimoto, `Tmax`
- 판정: `Tmax >= threshold`이면 In domain, 아니면 Out of domain

## 재현성 및 주의사항

- 19개 Tier 1, 2개 Tier 2, OECD TG414/TG421/TG416 모델을 포함합니다.
- TG416 모델은 scikit-learn 직렬화 호환성 문제를 피하기 위해 원래 GBT의 tree 구조를 손실 없이 JSON으로 변환했습니다.
- `SHA256SUMS.txt`로 포함 파일의 무결성을 확인할 수 있습니다.
- Tier 1 AD reference는 보존된 ToxCast fingerprint lineage와 기록된 80/20 split (`random_state=42`)을 이용해 모델-fit subset을 재구성했습니다. 상세 내용은 `method_audit.json`에 있습니다.
- Joblib 파일은 Python pickle 기반이므로 신뢰할 수 있는 이 패키지에서만 로드해야 합니다.
- 계산 예측은 규제 시험자료나 전문가 weight-of-evidence 판단을 대체하지 않습니다.

