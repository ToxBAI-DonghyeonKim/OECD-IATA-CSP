#!/bin/zsh
set -e
SCRIPT_DIR="${0:A:h}"
INPUT_PATH="$1"
if [[ -z "$INPUT_PATH" ]]; then
  echo "Usage: drag a CSV/XLSX file onto this command, or run: ./run_prediction.command input.csv"
  read -k 1
  exit 1
fi
OUTPUT_PATH="${INPUT_PATH:r}_ToxBAI24_predictions.xlsx"
python3 "$SCRIPT_DIR/predict_24.py" "$INPUT_PATH" -o "$OUTPUT_PATH"
echo "Created: $OUTPUT_PATH"
read -k 1
